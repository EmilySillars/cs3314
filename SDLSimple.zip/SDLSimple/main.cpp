#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <vector>
#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "Entity.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;




GameState state;
GLuint fontTextureID;
GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	stbi_image_free(image);
	return textureID;
}

void initializePlayer() {
	//initializing player
	state.player.entityType = PLAYER;
	state.player.gameState = &state;
	state.player.isStatic = false;
	state.player.position = glm::vec3(-4, 3, 0);
	state.player.acceleration = glm::vec3(0, -9.81f, 0);
	state.player.speed = 2;
	state.player.width = 1.0f;
	state.player.height = 1.0f;
	state.player.bottomColliderPosition = state.player.position - glm::vec3(0.7,0,0);
	state.player.bottomColliderHeight = 0.3;
	state.player.bottomColliderHeight = state.player.width;
	//player animation
	state.player.textureID = LoadTexture("assets/pandaSheet.png");
	state.player.spriteWidth = 1.0f;
	state.player.spriteHeight = 1.0f;
	state.player.cols = 3; //texture cols
	state.player.rows = 4; //texture rows
	state.player.walkRight = new int[5]{ 6,7,8,9,10 }; 
	state.player.walkLeft = new int[5]{ 2,1,0,5,4 }; 
	state.player.idleLeft = new int[5]{ 2,2,2,2,2 }; 
	state.player.idleRight = new int[5]{ 6,6,6,6,6 }; 
	state.player.currentAnim = state.player.idleRight;
	state.player.animFrames = 5;
}

void initializePlatforms() {
	GLuint dirtTextureID = LoadTexture("assets/dirt.png");
	GLuint grassTextureID = LoadTexture("assets/grass.png");

	for (int i = 0; i < 11; i++)
	{
		state.platforms[i].textureID = dirtTextureID;
		state.platforms[i].position = glm::vec3(i - 5.0f, -3.25f, 0);
	}

	state.platforms[11].textureID = grassTextureID;
	state.platforms[11].position = glm::vec3(-5.0f, -2.25f, 0);

	state.platforms[12].textureID = grassTextureID;
	state.platforms[12].position = glm::vec3(-4.0f, -2.25f, 0);

	state.platforms[13].textureID = grassTextureID;
	state.platforms[13].position = glm::vec3(5.0f, -2.25f, 0);

	for (int i = 0; i < PLATFORM_COUNT; i++) {
		//platforms should not move, so no acceleration due to gravity
		state.platforms[i].acceleration = glm::vec3(0, 0, 0);
		state.platforms[i].isStatic = true; //platforms are static
		//player animation
		state.platforms[i].speed = 0;
		state.platforms[i].cols = 1; //texture cols
		state.platforms[i].rows = 1; //texture rows
		state.platforms[i].walkRight = NULL; //4 frames, and these are their indices! (walking right)
		state.platforms[i].walkLeft = NULL; //4 frames, and these are their indices! (walking right)
		state.platforms[i].currentAnim = new int[1]{ 1 }; //just one frame
		state.platforms[i].animFrames = 1;
	}
}

void initializeEnemies() {
	//load texture id for font
	fontTextureID = LoadTexture("pixel_font.png");
	//load in enemy
	GLuint blockTextureID = LoadTexture("assets/ball.png");
	GLuint bugTextureID = LoadTexture("assets/beetleSheet.png");
	GLuint accordionTextureID = LoadTexture("assets/accordionSheet.png");
	state.gameMode = GAME_PLAYING;
	state.enemies[0].entityType = ENEMY;
	state.enemies[0].textureID = blockTextureID;
	state.enemies[0].isStatic = false; //it moves!!
	state.enemies[0].position = glm::vec3(-2.0f, 2.0f, 0.0f);
	state.enemies[0].aiState = WAITING;
	state.enemies[0].aiType = FALLER;
	//animation
	state.enemies[0].speed = 0;
	state.enemies[0].cols = 1; //texture cols
	state.enemies[0].rows = 1; //texture rows
	state.enemies[0].idleLeft = new int[1]{ 1 }; //just one frame
	state.enemies[0].idleRight = new int[1]{ 1 }; //just one frame
	state.enemies[0].walkRight = new int[1]{ 1 }; //4 frames, and these are their indices! (walking right)
	state.enemies[0].walkLeft = new int[1]{ 1 }; //4 frames, and these are their indices! (walking right)
	state.enemies[0].currentAnim = new int[1]{ 1 }; //just one frame
	state.enemies[0].animFrames = 1;

	//load second enemy
	state.enemies[1].entityType = ENEMY;
	state.enemies[1].textureID = bugTextureID;
	state.enemies[1].isStatic = false; //it moves!!
	state.enemies[1].position = glm::vec3(2.0f, -2.25f, 0.0f);
	state.enemies[1].aiState = IDLE;
	//animation
	state.enemies[1].speed = 0;
	state.enemies[1].cols = 5; //texture cols
	state.enemies[1].rows = 2; //texture rows
	state.enemies[1].height = 0.4f; 
	state.enemies[1].idleLeft = new int[1]{ 9 }; //just one frame
	state.enemies[1].idleRight = new int[1]{ 4 }; //just one frame
	state.enemies[1].walkRight = new int[1]{ 4 }; //4 frames, and these are their indices! (walking right)
	state.enemies[1].walkLeft = new int[1]{ 9 }; //4 frames, and these are their indices! (walking right)
	state.enemies[1].currentAnim = new int[1]{ 1 }; //just one frame
	state.enemies[1].animFrames = 1;
	state.enemies[1].aiType = WALKER;
	//load third enemy
	state.enemies[2].entityType = ENEMY;
	state.enemies[2].textureID = accordionTextureID;
	state.enemies[2].isStatic = false; //it moves!!
	state.enemies[2].position = glm::vec3(4.0f, -1.75f, 0.0f);
	state.enemies[2].aiState = EXPANDING;
	state.enemies[2].height = 0.1f;
	state.enemies[2].spriteWidth = 1.0f;
	state.enemies[2].spriteHeight =2.0f;
	//animation
	state.enemies[2].speed = 0;
	state.enemies[2].cols = 3; //texture cols
	state.enemies[2].rows = 4; //texture rows
	state.enemies[2].idleLeft = new int[10]{ 0,0,0,0,0,0,0,0,0,0 }; //just one frame
	state.enemies[2].walkRight = new int[10]{ 0,1,2,3,4,5,6,7,8,9}; //4 frames, and these are their indices! (walking right)
	state.enemies[2].walkLeft = state.enemies[2].walkRight; //4 frames, and these are their indices! (walking right)
	state.enemies[2].idleRight = new int[10]{ 9,9,9,9,9,9,9,9,9,9 }; //just one frame
	state.enemies[2].currentAnim = state.enemies[2].walkRight; //just one frame
	state.enemies[2].animFrames = 10;
	state.enemies[2].aiType = ACCORDION;
	state.enemies[2].aiState = EXPANDING;
	state.enemies[2].timer = 0;
}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("AI!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
	glewInit();
#endif

	glViewport(0, 0, 640, 480);

	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");

	initializePlayer();

	initializeEnemies();

	//initialize platforms
	initializePlatforms();


	viewMatrix = glm::mat4(1.0f);
	modelMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

	glUseProgram(program.programID);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
}



void ProcessInput() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
		case SDL_WINDOWEVENT_CLOSE:
			gameIsRunning = false;
			break;

		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
			case SDLK_SPACE:
				state.player.Jump();
				break;

			}
			break;
		}
	}

	state.player.velocity.x = 0;

	// Check for pressed/held keys below
	const Uint8 *keys = SDL_GetKeyboardState(NULL);

	if (keys[SDL_SCANCODE_A])
	{
		state.player.velocity.x = -3.0f;
	}
	else if (keys[SDL_SCANCODE_D])
	{
		state.player.velocity.x = 3.0f;
	}
}

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;

	deltaTime += accumulator;
	if (deltaTime < FIXED_TIMESTEP) {
		accumulator = deltaTime;
		return;
	}

	while (deltaTime >= FIXED_TIMESTEP) {
		// Update. Notice it's FIXED_TIMESTEP. Not deltaTime
		//update player!
		state.player.Update(FIXED_TIMESTEP, state.player,state.platforms, PLATFORM_COUNT, state.enemies, ENEMY_COUNT);
		//ai stuff here
		for (int i = 0; i < ENEMY_COUNT; i++) {
			//update all the AIs!
			state.enemies[i].Update(FIXED_TIMESTEP,state.player, state.platforms, PLATFORM_COUNT, state.enemies, ENEMY_COUNT);
		}
		deltaTime -= FIXED_TIMESTEP;
	}

	if ((!state.enemies[0].isActive) &&
		(!state.enemies[1].isActive) &&
		!state.enemies[2].isActive) {
		state.gameMode = GAME_WIN;
		glClearColor((153.0f / 255.0f), (204.0f / 255.0f), (255.0f / 255.0f), 1.0f);
	}

	accumulator = deltaTime;
}


void DrawText(ShaderProgram *program, GLuint fontTextureID, std::string text, float size, float spacing, glm::vec3 position) {
	float width = 1.0f / 16.0f;
	float height = 1.0f / 16.0f;

	std::vector<float> vertices;
	std::vector<float> texCoords;

	for (int i = 0; i < text.size(); i++) {
		int index = (int)text[i]; //ascii value of char

		float u = (float)(index % 16) / 16.0f;
		float v = (float)(index / 16) / 16.0f;

		texCoords.insert(texCoords.end(), { u, v + height, u + width, v + height, u + width,
											v, u, v + height, u + width, v, u, v });
		float offset = (size + spacing)*i;
		vertices.insert(vertices.end(), { offset + (-0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (0.5f * size),
											offset + (-0.5f *size), (-0.5f * size),
											offset + (0.5f *size), (0.5f * size),
											offset + (-0.5f *size), (0.5f * size) });
	}
	//familiar code
	glm::mat4 modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, position);
	program->SetModelMatrix(modelMatrix);

	glBindTexture(GL_TEXTURE_2D, fontTextureID);

	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices.data());
	glEnableVertexAttribArray(program->positionAttribute);

	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords.data());
	glEnableVertexAttribArray(program->texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, vertices.size() / 2.0f);

	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);

}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);
	if (state.gameMode == GAME_LOSE) {
		DrawText(&program, fontTextureID, "You Lose :(", 0.6f, 0.01f, glm::vec3(-3.0f, 2.5f, 0.0f));
	}
	else if (state.gameMode == GAME_WIN) {
		DrawText(&program, fontTextureID, "You Win!", 0.6f, 0.01f, glm::vec3(-2.0f, 2.5f, 0.0f));
	}
	state.player.Render(&program);
	//draw platforms
	for (int i = 0; i < PLATFORM_COUNT; i++)
	{
		state.platforms[i].Render(&program);
	}
	//draw enemies
	for (int i = 0; i < ENEMY_COUNT; i++)
	{
		state.enemies[i].Render(&program);
	}

	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		if (state.gameMode == GAME_PLAYING) { Update(); }
		Render();
	}

	Shutdown();
	return 0;
}

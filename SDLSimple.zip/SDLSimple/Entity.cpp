#include "Entity.h"

Entity::Entity()
{
	entityType = PLATFORM; //default
	isStatic = true; //default
	isActive = true; //default
	position = glm::vec3(0);
	speed = 0;
	width = 1.0f;
	height = 1.0f;
	spriteWidth = 1.0f;
	spriteHeight = 1.0f;
	//animation
	timer = 0;
	animTime = 0;
	animIndex = 0;
	aiType = WALKER;
	aiState = IDLE;
	//touchingGround = false;
	bottomColliderHeight = 0;
	bottomColliderWidth = 0;
	glm::vec3 bottomColliderPosition = position;
}

void Entity::playerDie() {
	(*gameState).gameMode = GAME_LOSE;
}


bool Entity::checkCollisionBottom(Entity *objects, int objectCount) {
	int count = 1;
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];
		bool collision = ((position.x > (object.position.x-width)) &&
					   (position.x < (object.position.x+width)) &&
					   (position.y-height-0.2 <(object.position.y+height)) &&
					   (position.y - height - 0.2 > (object.position.y - height)));
		if (collision)
		{
			if (entityType == PLAYER && object.entityType == ENEMY) {
				if (object.aiState != EXPANDING) {
					objects[i].isActive = false;
					count++;
				}
			}
		}

	}
	return (count == objectCount);
}


bool Entity::CheckCollision(Entity& other)
{
	if (isStatic == true) return false;
	if (isActive == false || other.isActive == false) return false;

	float xdist = fabs(position.x - other.position.x) - ((width + other.width) / 2.0f);
	float ydist = fabs(position.y - other.position.y) - ((height + other.height) / 2.0f);

	if (xdist < 0 && ydist < 0)
	{
		if (entityType == PLAYER && other.entityType == ENEMY)
		{
			playerDie();
		}
		return true;
	}

	return false;
}

void Entity::CheckCollisionsY(Entity *objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float ydist = fabs(position.y - object.position.y);
			float penetrationY = fabs(ydist - (height / 2) - (object.height / 2));
			if (velocity.y > 0) {
				position.y -= penetrationY;
				velocity.y = 0;
				collidedTop = true;
			}
			else if (velocity.y < 0) {
				position.y += penetrationY;
				velocity.y = 0;
				collidedBottom = true;
			}
		}
	}
}

void Entity::CheckCollisionsX(Entity *objects, int objectCount)
{
	for (int i = 0; i < objectCount; i++)
	{
		Entity object = objects[i];

		if (CheckCollision(object))
		{
			float xdist = fabs(position.x - object.position.x);
			float penetrationX = fabs(xdist - (width / 2) - (object.width / 2));
			if (velocity.x > 0) {
				position.x -= penetrationX;
				velocity.x = 0;
				collidedRight = true;
			}
			else if (velocity.x < 0) {
				position.x += penetrationX;
				velocity.x = 0;
				collidedLeft = true;
			}
		}
	}
}


void Entity::Jump()
{
	if (collidedBottom)
	{
		velocity.y = 5.0f;
	}
}
void Entity::AIFaller(Entity& player) {
	switch (aiState) { //do something different depending on state!
	case WAITING:
		glClearColor((153.0f / 255.0f), (204.0f / 255.0f), (255.0f / 255.0f), 1.0f);
		if (fabs(player.position.x - position.x) < 0.2f) {
			aiState = FALLING;
			acceleration.y = -9.81f;
			velocity.y = -1.0f;
		}
		break;
	case FALLING:
		glClearColor((255.0f / 255.0f), (223.0f / 255.0f), (128.0f / 255.0f), 1.0f);
		if (position.y < -4.0) {
			velocity.y = 0;
			acceleration.y = 0.0f;
				position.y = -1.0f;
			aiState = WAITING;
		}
		velocity.y = -1.0f;
		break;
	}
}
void Entity::AIAccordion(Entity& player, float deltaTime) {
	switch (aiState) { //do something different depending on state!
	case FLAT:
		timer += deltaTime;
		if (timer > 6.0f) {
			aiState = EXPANDING;
			currentAnim = walkRight;
			timer = 0.0f;
		}
		break;
	case EXPANDING:
		timer += deltaTime;
		if (timer > 10.0f) {
			aiState = FLAT;
			timer = 0.0f;
			height = 0.1f;
			currentAnim = idleLeft;
		}
		
	}
}

void Entity::AIWalker(Entity& player) {
	switch (aiState) { //do something different depending on state!
	case IDLE:
		if (glm::distance(position, player.position) < 3.0f) {
			aiState = WALKING;
		}
		break;
	case WALKING:
		if (player.position.x > position.x+0.2) {
			velocity.x = 1.0f; //go right	
		}
		if (player.position.x < position.x-0.2) {
			velocity.x = -1.0f; //go left	
		}
	}
}

void Entity::AI(Entity player, float deltaTime) {
	switch (aiType) {
	case WALKER:
		//call an AI walker function
		AIWalker(player);
		break;
	case FALLER:
		AIFaller(player);
		break;
	case ACCORDION:
		AIAccordion(player, deltaTime);
		break;
	}

}

void Entity::Update(float deltaTime, Entity player, Entity *objects, int objectCount, Entity *enemies, int enemyCount)
{
	collidedTop = false;
	collidedBottom = false;
	collidedLeft = false;
	collidedRight = false;
	//gravity
	velocity += acceleration * deltaTime;
	//AI
	if (entityType == ENEMY) {
		//call AI function!
		AI(player,deltaTime);
	}
	if (entityType == PLAYER) {
		checkCollisionBottom(enemies, enemyCount);
		CheckCollisionsY(enemies, enemyCount);    // check if i collided with any enemies
		CheckCollisionsX(enemies, objectCount);    // Fix if needed
	}

	position.y += velocity.y * deltaTime;        // Move on Y
	CheckCollisionsY(objects, objectCount);    // Fix if needed

	position.x += velocity.x * deltaTime;        // Move on X
	CheckCollisionsX(objects, objectCount);    // Fix if needed

	//update animation based on movement
	animTime += deltaTime;
	if ((entityType == ENEMY) && (aiType == ACCORDION)) {
		timer += deltaTime;
		if (aiState == EXPANDING) {
			if (animTime >= 0.0833f) //0.0666 means 12 fps
			{
				//animTime = 0;
				animIndex++;
				if (height >= 1.5f) {
					height = 1.5f;
				}
				else {
					height += 0.2f;
				}
				if (animIndex >= animFrames)
				{
					animIndex = 0;
					currentAnim = idleRight;
				}
			}
		}
		else {
			if (animTime >= 0.0833f) //0.0666 means 15 fps
			{
				//animTime = 0;
				animIndex++;
				if (animIndex >= animFrames)
				{
					animIndex = 0;
				}
			}
		}
		
	}
	else {
		if (animTime >= 0.25f) //0.25 means 4 fps
		{
			animTime = 0;
			animIndex++;
			if (animIndex >= animFrames)
			{
				animIndex = 0;
			}
		}
	}
}




void Entity::DrawSpriteFromTextureAtlas(ShaderProgram *program, int index)
{
	float u = (float)(index % cols) / (float)cols;
	float v = (float)(index / cols) / (float)rows;

	float width = 1.0f / (float)cols;
	float height = 1.0f / (float)rows;

	float texCoords[] = { u, v + height, u + width, v + height, u + width, v,
		u, v + height, u + width, v, u, v };
	float x = spriteWidth / 2;
	float y = spriteHeight / 2;
	float vertices[] = { -1 * x, -1 * y, x, -1 * y, x, y, -1 * x, -1 * y, x, y, -1 * x, y };

	glBindTexture(GL_TEXTURE_2D, textureID);

	glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program->positionAttribute);

	glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(program->texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program->positionAttribute);
	glDisableVertexAttribArray(program->texCoordAttribute);
}

void Entity::Render(ShaderProgram *program) {
	if (!isActive) { return; }
	glm::mat4 modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, position);
	program->SetModelMatrix(modelMatrix);
	if (velocity.x < 0) {
		DrawSpriteFromTextureAtlas(program, walkLeft[animIndex]);
		currentAnim = idleLeft;
	}
	else if (velocity.x > 0) {
		DrawSpriteFromTextureAtlas(program, walkRight[animIndex]);
		currentAnim = idleRight;
	}
	else {
		DrawSpriteFromTextureAtlas(program, currentAnim[animIndex]);
	}
}


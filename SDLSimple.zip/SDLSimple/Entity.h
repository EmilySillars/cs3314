#pragma once
#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define PLATFORM_COUNT 14
#define ENEMY_COUNT 3
enum GameMode { GAME_PLAYING, GAME_WIN, GAME_LOSE };
struct GameState;

enum  EntityType { PLAYER, PLATFORM, COIN, ENEMY };
enum AIState { IDLE, WALKING, WAITING, FALLING, FLAT, EXPANDING }; //add AI states
enum AIType { WALKER, FALLER, ACCORDION };

class Entity {
public:
	GameState* gameState;
	EntityType entityType;
	//AI
	AIState aiState; //to store state of enemy
	AIType aiType;

	bool isStatic;
	bool isActive;

	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 acceleration;
	glm::vec3 bottomColliderPosition;
	float bottomColliderWidth;
	float bottomColliderHeight;
	float width;
	float height;

	float speed;

	GLuint textureID;
	int cols;
	int rows;
	int *idleRight;
	int *idleLeft;
	int *walkRight;
	int *walkLeft;
	int *currentAnim;
	int animFrames;
	int animIndex;
	float animTime;
	float spriteWidth;
	float spriteHeight;

	float timer;
	//constructor
	Entity();

	//methods
	void playerDie();
	bool CheckCollision(Entity& other);
	void CheckCollisionsX(Entity *objects, int objectCount);
	void CheckCollisionsY(Entity *objects, int objectCount);
	bool overlapsX(glm::vec3 otherPosition, float otherWidth);
	bool overlapsY(glm::vec3 otherPosition, float otherHeight);
	bool checkCollisionBottom(Entity *objects, int objectCount);
	void Update(float deltaTime, Entity player, Entity *objects, int objectCount, Entity *enemies, int enemyCount); //added in player so AI can see it
	//more AI
	void AI(Entity player, float deltaTime); //basically Ai update
	void AIWalker(Entity& player);
	void AIFaller(Entity& player);
	void AIAccordion(Entity& player, float deltaTime);

	void Render(ShaderProgram *program);
	void DrawSpriteFromTextureAtlas(ShaderProgram *program, int index);
	void Jump();

	//collision flags
	bool collidedTop;
	bool collidedBottom;
	bool collidedLeft;
	bool collidedRight;
	//bool touchingGround;
};



struct GameState {
	Entity player;
	Entity platforms[PLATFORM_COUNT];
	Entity enemies[ENEMY_COUNT];
	GameMode gameMode;
};